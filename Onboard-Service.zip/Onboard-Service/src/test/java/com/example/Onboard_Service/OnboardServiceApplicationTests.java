package com.example.Onboard_Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnboardServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
